
module.exports = require('./lib/cluster');