"use strict";

module.exports = { pad: require("./pad") };
