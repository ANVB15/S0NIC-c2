exports.compress = require('./compress');
exports.decompress = require('./dec/decode').BrotliDecompressBuffer;
